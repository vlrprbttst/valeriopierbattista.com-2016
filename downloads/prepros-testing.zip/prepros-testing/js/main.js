//@prepros-append jquery-1.9.1.min.js
//@prepros-append waypoints.min.js
//@prepros-append jquery.flexslider.js

// scrollspy

// Cache selectors
var lastId,
    topMenu = $("nav"),
    topMenuHeight = topMenu.outerHeight()+15,
    // All list items
    menuItems = topMenu.find("a"),
    // Anchors corresponding to menu items
    scrollItems = menuItems.map(function(){
      var item = $($(this).attr("href"));
      if (item.length) { return item; }
    });



// Bind to scroll
$(window).scroll(function(){
   // Get container scroll position
   var fromTop = $(this).scrollTop()+topMenuHeight;

   // Get id of current scroll item
   var cur = scrollItems.map(function(){
     if ($(this).offset().top < fromTop)
       return this;
   });
   // Get the id of the current element
   cur = cur[cur.length-1];
   var id = cur && cur.length ? cur[0].id : "";

   if (lastId !== id) {
       lastId = id;
       // Set/remove active class
       menuItems
         .parent().removeClass("active-state-navigation")
         .end().filter("[href=#"+id+"]").parent().addClass("active-state-navigation");
   }                   
});

(function() {

  (function(root, factory) {
    if (typeof define === 'function' && define.amd) {
      return define(['jquery', 'waypoints'], factory);
    } else {
      return factory(root.jQuery);
    }
  })(this, function($) {
    var defaults, wrap;
    defaults = {
      wrapper: '<div class="sticky-wrapper" />',
      stuckClass: 'fixed-nav'
    };
    wrap = function($elements, options) {
      $elements.wrap(options.wrapper);
      $elements.each(function() {
        var $this;
        $this = $(this);
        $this.parent().height($this.outerHeight());
        return true;
      });
      return $elements.parent();
    };
    return $.waypoints('extendFn', 'sticky', function(options) {
      var $wrap, originalHandler;
      options = $.extend({}, $.fn.waypoint.defaults, defaults, options);
      $wrap = wrap(this, options);
      originalHandler = options.handler;
      options.handler = function(direction) {
        var $sticky, shouldBeStuck;
        $sticky = $(this).children(':first');
        shouldBeStuck = direction === 'down' || direction === 'right';
        $sticky.toggleClass(options.stuckClass, shouldBeStuck);
        if (originalHandler != null) {
          return originalHandler.call(this, direction);
        }
      };
      $wrap.waypoint(options);
      return this;
    });
  });

}).call(this);

$(document).ready(function() {
	$('nav').waypoint('sticky');
	
});	

// antiscroll

(function(e){function t(t,r){this.el=e(t);this.options=r||{};this.padding=undefined==this.options.padding?2:this.options.padding;this.inner=this.el.find(".antiscroll-inner");this.inner.css({width:"+="+s(),height:"+="+s()});if(this.inner.get(0).scrollWidth>this.el.width()){this.horizontal=new n.Horizontal(this)}if(this.inner.get(0).scrollHeight>this.el.height()){this.vertical=new n.Vertical(this)}}function n(t){this.pane=t;this.pane.el.append(this.el);this.innerEl=this.pane.inner.get(0);this.dragging=false;this.enter=false;this.shown=false;this.pane.el.mouseenter(e.proxy(this,"mouseenter"));this.pane.el.mouseleave(e.proxy(this,"mouseleave"));this.el.mousedown(e.proxy(this,"mousedown"));this.pane.inner.scroll(e.proxy(this,"scroll"));this.pane.inner.bind("mousewheel",e.proxy(this,"mousewheel"));var n=this;this.show();this.hiding=setTimeout(e.proxy(this,"hide"),3e3)}function r(e,t){function n(){}n.prototype=t.prototype;e.prototype=new n}function s(){if(!i){var t=e('<div style="width:50px;height:50px;overflow:hidden;'+'position:absolute;top:-200px;left:-200px;"><div style="height:100px;">'+"</div>");e("body").append(t);var n=e("div",t).innerWidth();t.css("overflow-y","scroll");var r=e("div",t).innerWidth();e(t).remove();i=n-r}return i}e.fn.antiscroll=function(t){return this.each(function(){if(!e(this).data("antiscroll")){e(this).data("antiscroll",new e.Antiscroll(this,t))}})};e.Antiscroll=t;n.prototype.mouseenter=function(){this.enter=true;this.show()};n.prototype.mouseleave=function(){this.enter=false;if(!this.dragging){this.hide()}};n.prototype.scroll=function(){if(!this.shown){this.show()}this.update()};n.prototype.mousedown=function(t){t.preventDefault();this.dragging=true;this.startPageY=t.pageY-parseInt(this.el.css("top"),10);this.startPageX=t.pageX-parseInt(this.el.css("left"),10);document.onselectstart=function(){return false};var n=this.pane,r=e.proxy(this,"mousemove"),i=this;e(document).mousemove(r).mouseup(function(){i.dragging=false;document.onselectstart=null;e(document).unbind("mousemove",r);if(!i.enter){i.hide()}})};n.prototype.show=function(e){if(!this.shown){this.update();this.el.addClass("antiscroll-scrollbar-shown");if(this.hiding){clearTimeout(this.hiding);this.hiding=null}this.shown=true}};n.prototype.hide=function(){if(this.shown){this.el.removeClass("antiscroll-scrollbar-shown");this.shown=false}};n.Horizontal=function(t){this.el=e('<div class="antiscroll-scrollbar antiscroll-scrollbar-horizontal">');n.call(this,t)};r(n.Horizontal,n);n.Horizontal.prototype.update=function(){var e=this.pane.el.width(),t=e-this.pane.padding*2,n=this.pane.inner.get(0);this.el.css("width",t*e/n.scrollWidth).css("left",t*n.scrollLeft/n.scrollWidth)};n.Horizontal.prototype.mousemove=function(e){var t=this.pane.el.width()-this.pane.padding*2,n=e.pageX-this.startPageX,r=this.el.width(),i=this.pane.inner.get(0);var s=Math.min(Math.max(n,0),t-r);i.scrollLeft=(i.scrollWidth-this.pane.el.width())*s/(t-r)};n.Horizontal.prototype.mousewheel=function(e,t,n,r){if(n<0&&0==this.pane.inner.get(0).scrollLeft||n>0&&this.innerEl.scrollLeft+this.pane.el.width()==this.innerEl.scrollWidth){e.preventDefault();return false}};n.Vertical=function(t){this.el=e('<div class="antiscroll-scrollbar antiscroll-scrollbar-vertical">');n.call(this,t)};r(n.Vertical,n);n.Vertical.prototype.update=function(){var e=this.pane.el.height(),t=e-this.pane.padding*2,n=this.innerEl;this.el.css("height",t*e/n.scrollHeight).css("top",t*n.scrollTop/n.scrollHeight)};n.Vertical.prototype.mousemove=function(e){var t=this.pane.el.height(),n=t-this.pane.padding*2,r=e.pageY-this.startPageY,i=this.el.height(),s=this.innerEl;var o=Math.min(Math.max(r,0),n-i);s.scrollTop=(s.scrollHeight-t)*o/(n-i)};n.Vertical.prototype.mousewheel=function(e,t,n,r){if(r>0&&0==this.innerEl.scrollTop||r<0&&this.innerEl.scrollTop+this.pane.el.height()==this.innerEl.scrollHeight){e.preventDefault();return false}};var i;})(jQuery)




// scroll whole website 




$(document).ready(function() {

	$("nav ul li a,.logo-ribbon a").bind("click", function(a) {
		var b = $(this);
		$("html, body").stop().animate({
			scrollTop : $(b.attr("href")).offset().top
		}, 2000);
		a.preventDefault()
	})
	
	
	// TABS FAQ (standalone) ////////////////////////////////////////////////////////////////////////////////////////////
	
	$('ul.tabs').each(function() {
		var $active, $content, $links = $(this).find('a');
		$active = $($links.filter('[href="'+location.hash+'"]')[0] || $links[0]);
		$active.addClass('active');
		$content = $($active.attr('href'));
		$links.not($active).each(function() {
			$($(this).attr('href')).hide();
		});
		$(this).on("click", "a", function(e) {
			$active.removeClass('active');
			$content.hide();
			$active = $(this);
			$content = $($(this).attr('href'));
			$active.addClass('active');
			$content.show();
			e.preventDefault();
		});
	});
	
	// accordion
	
	$(".accordionContent").hide();
    $(".accordionButton").click(function(){
        $(this).next().slideToggle('slow', function(){
            $(this).prev(".accordionButton").toggleClass("active");
        });
    return false;
});
	

	// FLEXSLIDER (jquery.flexslider.js) //////////////////////////////////////////////////////////////////////////////////
$('.flexslider').flexslider({
		animation : "slide",
		controlsContainer : ".flex-container"
	});
	var scrolling = false;
	
	

	// SCROLL IFRAME (antiscroll.js) ////////////////////////////////////////////////////////////////////////////////////////////////
	
	setTimeout(function() {
		$('.msite').antiscroll()
	}, 3000);


	
	// BACK TO TOP (standalone) ////////////////////////////////////////////////////////////////////////
$(window).scroll(function(){
		if ($(this).scrollTop() > 100) {
			$('.scrollToTop').fadeIn();
		} else {
			$('.scrollToTop').fadeOut();
		}
	});
	
	$('.scrollToTop').click(function(){
		$('html, body').animate({scrollTop : 0},800);
		return false;
	});
});


$(window).scroll(function() {    

    var scroll = $(window).scrollTop();

    if (scroll >= 50) {
        
        $(".first-part").addClass("separate-left");
		$(".second-part").addClass("separate-right");
    } else {
        
        $(".first-part").removeClass("separate-left");
		$(".second-part").removeClass("separate-right");
    }
	
	if (scroll >= 250) {
        
        $(".logo").addClass("logo-disappear");
		$(".logo-ribbon").addClass("logo-ribbon-appear");
		
    } else {
        
        $(".logo").removeClass("logo-disappear");
		$(".logo-ribbon").removeClass("logo-ribbon-appear");
		
    }
});



// tool tip /////

var ddimgtooltip={tiparray:function(){var e=[];e[0]=["/site/images/screen.jpg"];e[1]=["/site/images/screen-404.jpg"];return e}(),tooltipoffsets:[20,30],tipprefix:"imgtip",createtip:function(e,t,n){if(e("#"+t).length==0){return e('<div id="'+t+'" class="ddimgtooltip" />').html('<div style="text-align:center"><img src="'+n[0]+'" /></div>'+(n[1]?'<div style="text-align:left; margin-top:5px">'+n[1]+"</div>":"")).css(n[2]||{}).appendTo(document.body)}return null},positiontooltip:function(e,t,n){var r=n.pageX+this.tooltipoffsets[0],i=n.pageY+this.tooltipoffsets[1];var s=t.outerWidth(),o=t.outerHeight(),r=r+s>e(document).scrollLeft()+e(window).width()?r-s-ddimgtooltip.tooltipoffsets[0]*2:r;i=i+o>e(document).scrollTop()+e(window).height()?e(document).scrollTop()+e(window).height()-o-10:i;t.css({left:r,top:i})},showbox:function(e,t,n){t.show();this.positiontooltip(e,t,n)},hidebox:function(e,t){t.hide()},init:function(e){jQuery(document).ready(function(t){var n=ddimgtooltip.tiparray;var r=t(e);if(r.length==0)return;var i=[];r.each(function(){var e=t(this);e.attr("rel").match(/\[(\d+)\]/);var r=parseInt(RegExp.$1);var i=this._tipid=ddimgtooltip.tipprefix+r;var s=ddimgtooltip.createtip(t,i,n[r]);e.mouseenter(function(e){var n=t("#"+this._tipid);ddimgtooltip.showbox(t,n,e)});e.mouseleave(function(e){var n=t("#"+this._tipid);ddimgtooltip.hidebox(t,n)});e.mousemove(function(e){var n=t("#"+this._tipid);ddimgtooltip.positiontooltip(t,n,e)});if(s){s.mouseenter(function(){ddimgtooltip.hidebox(t,t(this))})}})})}};ddimgtooltip.init("*[rel^=imgtip]")



					
//  waypoints
jQuery(document).ready(function($){		
		$(".ticket-container").waypoint(function () {
$('.animationBegin').removeClass('animationBegin'); 

}, { offset: 445 });	

		$(".dotted").waypoint(function () {
$('.animationBegin-d').removeClass('animationBegin-d');
}, { offset: 345 });	

$(".explosion").waypoint(function () {
$('.animationBegin2').removeClass('animationBegin2');
}, { offset: 345 });

$(".code-cont").waypoint(function () {
$('.animationBegin3').removeClass('animationBegin3');
}, { offset: 345 });

$(".code-anim").waypoint(function () {
$('.animationBegin5').removeClass('animationBegin5');
}, { offset: 345 });

$(".rocket").waypoint(function () {
$('.animationBegin4').removeClass('animationBegin4');
}, { offset: 345 });
						
})();

						


